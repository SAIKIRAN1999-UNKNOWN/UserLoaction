package com.example.myapplication;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;



public class SplashScreen extends Activity {

    private Context context;



    private ImageView splashIv;
    private RelativeLayout brandLayout;
    private boolean isAnimEnded = false;
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private static final int REQUEST_PERMISSION_SETTING = 101;
    String[] permissionsRequired = new String[]{
//            Manifest.permission.WRITE_EXTERNAL_STORAGE,
//            Manifest.permission.READ_EXTERNAL_STORAGE,
//            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
//            Manifest.permission.CAMERA
    };
    private SharedPreferences permissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        context = SplashScreen.this;



        permissionStatus = PreferenceManager
                .getDefaultSharedPreferences(context);



        Animation anim = AnimationUtils.loadAnimation(context,
                R.anim.splash_screen);

        brandLayout.setVisibility(View.VISIBLE);
        brandLayout.startAnimation(anim);

        isAnimEnded = true;
        anim.setAnimationListener(listener);
        setAllStrings();

        LocationManager locationManager = (LocationManager) context
                .getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null) {
            // getting GPS status
            boolean isGPSEnabled = locationManager
                    .isProviderEnabled(LocationManager.GPS_PROVIDER);

            // getting network status
            boolean isNetworkEnabled = locationManager
                    .isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            Intent intent = new Intent("com.spoton.pud.LOCATION_READY");

            PendingIntent launchIntent = PendingIntent.getBroadcast(context, 0, intent, 0);
            if (isNetworkEnabled) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER, 0, 0, launchIntent);
            } else if (isGPSEnabled) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER, 0, 0, launchIntent);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // register GCM registration complete receiver

    }

    @Override
    protected void onPause() {
        if (mRegistrationBroadcastReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
        }
        super.onPause();
    }

    private Animation.AnimationListener listener = new Animation.AnimationListener() {
        @Override
        public void onAnimationStart(Animation animation) {
            isAnimEnded = false;
        }

        @Override
        public void onAnimationRepeat(Animation animation) {

        }

        @Override
        public void onAnimationEnd(Animation animation) {
            isAnimEnded = true;

                goNext();

        }
    };

    private void displayFirebaseRegId() {

    }

    public void setAllStrings() {

    }

    private void checkPermissions() {
        Log.d("Permission Granted", ContextCompat.checkSelfPermission(this, permissionsRequired[0]) + "");
        Log.d("ActivityCompat ", ActivityCompat.checkSelfPermission(this, permissionsRequired[0]) + "");
        if (
                  ContextCompat.checkSelfPermission(this, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED
//                || ContextCompat.checkSelfPermission(this, permissionsRequired[3]) != PackageManager.PERMISSION_GRANTED
//                || ContextCompat.checkSelfPermission(this, permissionsRequired[4]) != PackageManager.PERMISSION_GRANTED
//                || ContextCompat.checkSelfPermission(this, permissionsRequired[5]) != PackageManager.PERMISSION_GRANTED
//                || ContextCompat.checkSelfPermission(this, permissionsRequired[6]) != PackageManager.PERMISSION_GRANTED
        ) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[0])
                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[1])
                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[2])
//                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[3])
//                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[4])
//                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[5])
//                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[6])
            ) {
                //Show Information about why you need the permission
                AlertDialog.Builder builder = new AlertDialog.Builder(SplashScreen.this);
                builder.setTitle("Need Multiple Permissions");
                builder.setMessage("This app needs Camera and Location permissions.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions(SplashScreen.this, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            } else {
                //just request the permission
                ActivityCompat.requestPermissions(SplashScreen.this, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
            }


            SharedPreferences.Editor editor = permissionStatus.edit();
            editor.putBoolean(permissionsRequired[0], true);
            editor.commit();
        } else {
            //You already have the permission, just go ahead.
            proceedAfterPermission();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_CALLBACK_CONSTANT) {
            //check if all permissions are granted
            boolean allgranted = false;
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    allgranted = true;
                } else {
                    allgranted = false;
                    break;
                }
            }

            if (allgranted) {
                proceedAfterPermission();
            } else if (ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[0])
                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[1])
                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[2])
//                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[3])
//                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[4])
//                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[5])
//                    || ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this, permissionsRequired[6])
            ) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SplashScreen.this);
                builder.setTitle("Need Multiple Permissions");
                builder.setMessage("This app needs Camera and Location permissions.");
                builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions(SplashScreen.this, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            } else {
                proceedAfterPermission();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PERMISSION_SETTING) {
            if (ContextCompat.checkSelfPermission(SplashScreen.this, permissionsRequired[0]) == PackageManager.PERMISSION_GRANTED) {
                //Got Permission
                proceedAfterPermission();
            }
        }
    }

    private void proceedAfterPermission() {
//        Utils.logD("in proceedAfterPermission");
        goNext();
    }

    private void goNext() {
//        String logout = dataSource.sharedPreferences.getValue(Constants.LOGOUT_PREF);
//        Utils.logD("in goNext");
//        Utils.writeToAudit(context, "in goNext " + logout);
//        Intent intent = null;
//        if (Utils.isValidString(logout)) {
//            Utils.logD("in Utils.isValidString(logout) if block");
//            Utils.writeToAudit(context, "in Utils.isValidString(logout) if block");
//            String date = dataSource.sharedPreferences.getValue(Constants.CHECK_UPGRADE_DATE_PREF);
//            if (Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF)) {
//                Utils.writeToAudit(context, "in Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF) if block");
//                Utils.logD("in Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF) if block");
//                int c = dataSource.pickupsData.getInProgressCount();
//                if (c == 0) {
//                    callLogout();
//                    return;
//                } else {
//                    intent = new Intent(context, DashboardActivity.class);
//                }
//            }
//            else {
//                Utils.writeToAudit(context, "in Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF) else block");
//                Utils.logD("in Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF) else block");
//                if (logout.equalsIgnoreCase(Constants.FALSE)) {
//                    Utils.writeToAudit(context, "in Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF) logout.equalsIgnoreCase(Constants.FALSE) if block");
//                    Utils.logD("in Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF) logout.equalsIgnoreCase(Constants.FALSE) if block");
//                    intent = new Intent(context, DashboardActivity.class);
//                } else if (logout.equalsIgnoreCase(Constants.TRUE)) {
//                    Utils.writeToAudit(context, "in Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF) logout.equalsIgnoreCase(Constants.FALSE) else block");
//                    Utils.logD("in Utils.isValidString(date) && !Utils.checkIfCalledToday(context, Constants.CHECK_UPGRADE_DATE_PREF) logout.equalsIgnoreCase(Constants.FALSE) else block");
//                    intent = new Intent(context, LoginActivity.class);
//                }
//            }
//        } else {
//            Utils.writeToAudit(context, "in Utils.isValidString(logout) else block");
//            Utils.logD("in Utils.isValidString(logout) else block");
//            intent = new Intent(context, LoginActivity.class);
//        }
//        if (intent != null) {
//            startActivity(intent);
//        }
        startActivity(new Intent(SplashScreen.this,HomeScreen.class));
    }

    public void callLogout() {
//        if (Utils.getConnectivityStatus(context))
//            new LogoutTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

//    class LogoutTask extends AsyncTask<Object, Object, Object> {
//        LoginAuthenticationModel model = new LoginAuthenticationModel();
//        GeneralResponse response = null;
//
//        @Override
//        protected void onPreExecute() {
//            Globals.lastErrMsg = "";
//            model.setImei(dataSource.sharedPreferences.getValue(Constants.IMEI));
//            String version = dataSource.sharedPreferences.getValue(Constants.VERSION_PREF);
//            if (Utils.isValidString(version))
//                model.setAppVersion(Integer.parseInt(version));
//            model.setUserId(dataSource.sharedPreferences.getValue(Constants.USERNAME_PREF));
//            model.setPassword(Utils.stringToSHA(dataSource.sharedPreferences.getValue(Constants.PASSWORD_PREF)));
//        }
//
//        @Override
//        protected Object doInBackground(Object... params) {
//            try {
//                Globals.lastErrMsg = "";
//                String username = dataSource.sharedPreferences.getValue(Constants.USERNAME_PREF);
//                String deviceId = dataSource.sharedPreferences.getValue(Constants.DEVICE_ID_PREF);
//                String url = VXUtils.getLogoutUrl();
//                Utils.logD("Log 1");
//                Gson gson = new Gson();
//                String jsonStr = gson.toJson(model, LoginAuthenticationModel.class);
//                response = (GeneralResponse) HttpRequest
//                        .postData(url, jsonStr, GeneralResponse.class,
//                                context);
//                if (response != null) {
//                    Utils.logD("Log 4");
//                    Utils.logD(response.toString());
//                    if (response.isStatus()) {
//                        clearData();
//                    } else {
//                        Globals.lastErrMsg = response.getMessage();
//                    }
//                }
//
//            } catch (Exception e) {
//                if (!Utils.isValidString(Globals.lastErrMsg))
//                    Globals.lastErrMsg = e.toString();
//            }
//            return null;
//
//        }
//
//        @Override
//        protected void onPostExecute(Object result) {
//            if (response != null && response.isStatus()) {
//                logout();
//            } else {
//                clearData();
//                logout();
//            }
//
//            super.onPostExecute(result);
//        }
//
//    }

    private void clearData() {
//        dataSource.sharedPreferences.set(Constants.LOGOUT_PREF, Constants.TRUE);
//        dataSource.sharedPreferences.delete(Constants.CHECK_UPGRADE_DATE_PREF);
//        dataSource.sharedPreferences.delete(Constants.PACKING_PULL_TIME_PREF);
//        dataSource.sharedPreferences.delete(Constants.PINCODES_PULL_TIME_PREF);
//        dataSource.sharedPreferences.delete(Constants.PAYMENT_TYPE_PULL_TIME_PREF);
//        dataSource.sharedPreferences.delete(Constants.MEASREMENT_PULL_TIME_PREF);
//        dataSource.sharedPreferences.delete(Constants.DOCKETS_PULL_TIME_PREF);
//        dataSource.sharedPreferences.delete(Constants.REASONS_PULL_TIME_PREF);
//        dataSource.sharedPreferences.delete(Constants.BOOKING_MODES_PULL_TIME_PREF);
//        dataSource.sharedPreferences.delete(Constants.COMMODITIES_PULL_TIME_PREF);
//        dataSource.dropAllTables();
    }

    private void logout() {
//        Intent intent = new Intent(context, LoginActivity.class);
//        startActivity(intent);
//        finishAffinity();
    }

}
