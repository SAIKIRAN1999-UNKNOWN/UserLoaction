package com.example.myapplication;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;


import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class GatherLocation implements LocationListener {

	// flag for GPS status
	boolean isGPSEnabled = false;

	// flag for network status
	boolean isNetworkEnabled = false;

	// Declaring a Location Manager
	protected LocationManager locationManager;

	public GatherLocation() {
		super();
	}

	private boolean isSuccess = false;
	private AsyncTask<String, Void, Void> postToServer;

	public boolean sendLocationToServer(final Context context,
										final Location location) {

		// Log.i("ASHISH", "start ");
		isSuccess = false;
		if (context != null && location != null) {
			int locationType = 1;
			if (location.getProvider().equals(LocationManager.NETWORK_PROVIDER))
				locationType = 2;
			/*try{
				String gid = Globals.getPrefs(context, "Geofence_id");
				String lat = Globals.getPrefs(context, "Geofence_lat");
				String lon = Globals.getPrefs(context, "Geofence_lon");;
				String radius = Globals.getPrefs(context, "Geofence_radius");
				CheckViolation.configure(context,gid,lat,lon,radius);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}*/
//			String locationJson = Globals.constructJsonLocation(context,
//					location.getLatitude(), location.getLongitude(),
//					location.getAccuracy(), locationType);
//			DataSource dataSource = new DataSource(context);
//			postToServer = new PostToServer().execute(
//					Globals.getUrlPushLocation(), locationJson,
//					dataSource.sharedPreferences.getValue(Constants.DEVICE_ID_PREF));
			try {
				if (postToServer != null)
					postToServer.get();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
		}

		// Log.i("ASHISH", "end " + isSuccess);

		return isSuccess;
	}

	/**
	 * Asynctask to post to server
	 */
//	private class PostToServer extends AsyncTask<String, Void, Void> {
//
//		@Override
//		protected Void doInBackground(String... args) {
//			try {
//				// String responseStr = null;
//				HttpResponse response = null;
//
//				String url = args[0];
//				String data = args[1];
//
//				try {
//					ArrayList<TagAndValue> headers = new ArrayList<TagAndValue>();
//					headers.add(new TagAndValue("deviceId", args[2]));
//
//					response = HttpRequestUtil.postData(url, data, headers);
//				} catch (ExceptionUtil e) {
//					response = null;
//					// responseStr = null;
//				}
//
//				if (response != null) {
//					isSuccess = true;
//					// try {
//					// responseStr = EntityUtils
//					// .toString(response.getEntity());
//					// } catch (IOException e) {
//					// }
//					//
//					// if (CommonUtilities.isValidString(responseStr)) {
//					// Log.e("ASHISH", "Loction post response : "
//					// + responseStr);
//					// }
//				}
//			} catch (Exception e) {
////				LogUtil.error(PostToServer.class, e.toString());
//			}
//			return null;
//		}
//	}

	public Location getLocation(Context context) {
		Location location = null;
		try {

			if (locationManager == null) {
				locationManager = (LocationManager) context
						.getSystemService(Context.LOCATION_SERVICE);
			}

			// getting GPS status
			isGPSEnabled = locationManager
					.isProviderEnabled(LocationManager.GPS_PROVIDER);

			// getting network status
			isNetworkEnabled = locationManager
					.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

			if (!isGPSEnabled && !isNetworkEnabled) {
				// no network provider is enabled
			} else {
				// First get location from Network Provider
				if (isNetworkEnabled) {
					if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
						// TODO: Consider calling
						//    ActivityCompat#requestPermissions
						// here to request the missing permissions, and then overriding
						//   public void onRequestPermissionsResult(int requestCode, String[] permissions,
						//                                          int[] grantResults)
						// to handle the case where the user grants the permission. See the documentation
						// for ActivityCompat#requestPermissions for more details.
						return null;
					}
					locationManager.requestLocationUpdates(
							LocationManager.NETWORK_PROVIDER, 0, 0, this);
					if (locationManager != null) {
						location = locationManager
								.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
					}
				}
				// if GPS Enabled get lat/long using GPS Services
				if (isGPSEnabled) {
					if (location == null) {
						locationManager.requestLocationUpdates(
								LocationManager.GPS_PROVIDER, 0, 0, this);
						if (locationManager != null) {
							location = locationManager
									.getLastKnownLocation(LocationManager.GPS_PROVIDER);
						}
					}
				}
			}

		} catch (Exception e) {
//			LogUtil.error(LocationService.class, e.toString());
			location = null;
		}

		return location;
	}

	/**
	 * 
	 * Stop using GPS listener Calling this function will stop using GPS
	 * 
	 * */
	public void stopUsing() {
		try {
			if (locationManager != null) {
				locationManager.removeUpdates(GatherLocation.this);
				locationManager = null;
			}
		} catch (Exception e) {
		}
	}

	@Override
	public void onLocationChanged(Location location) {
	}

	@Override
	public void onProviderDisabled(String provider) {
	}

	@Override
	public void onProviderEnabled(String provider) {
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
	}

}