package com.example.myapplication;

import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class HomeScreen extends AppCompatActivity {

    Button getLoc;
    TextView longi,lat;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getLoc = findViewById(R.id.btn_getLocation);
        longi = findViewById(R.id.tv_longi);
        lat = findViewById(R.id.tv_lati);
        getLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GatherLocation gatherLocation = new GatherLocation();
                Location location = gatherLocation.getLocation(HomeScreen.this);
                if (location != null) {

                    longi.setText(location.getLatitude()+"");
                    lat.setText(location.getLongitude()+"");
                }else{
                    Toast.makeText(HomeScreen.this,"Please Try Again",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
